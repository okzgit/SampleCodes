app.config(['$routeProvider', function($routeProvider) {
    $routeProvider
                    .when('/info', {
                                        templateUrl: 'information.html',
                                        controller: 'infoUser'
                                    })

                    .when ('/filter', {
                                        templateUrl: 'filter.html',
                                        controller: 'filterUser'
                            })
                    .otherwise({redirectTo: '/'});
                            
}]);