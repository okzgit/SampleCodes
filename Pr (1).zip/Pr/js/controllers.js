app.controller('userCtrl', function($scope, $http) {
    $scope.model =  'Thank you for your attention'
   
});

app.controller('infoUser', function($scope, $http) {
    $http.get('user.json')
    .success(function(result) {
        $scope.infoResult = result
    });
});


app.controller('filterUser', function($scope, $http) {
    $http.get('user.json')
    .success(function(result) {
        $scope.filterResult = result
    });
});